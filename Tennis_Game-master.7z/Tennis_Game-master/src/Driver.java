
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TennisGame play = new TennisGame(0, 0);
		
		while (play.getScore() == "") {
			if(Math.random() < 0.5) {
				play.addPlayer1Score();
			} else {
				play.addPlayer2Score();
			}
		}
	}
}
