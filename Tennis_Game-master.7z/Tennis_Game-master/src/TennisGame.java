
public class TennisGame {
	
	private int p1;
	private int p2;
	
	public TennisGame(int player1, int player2) {
		p1 = player1;
		p2 = player2;
	}
		
	public void setPlayer1Score(int score) {
		p1 = score;
	}
	
	public void setPlayer2Score(int score) {
		p2 = score;
	}
	

	public void addPlayer1Score() {
		if (getPlayer1Score() < 3) {
			setPlayer1Score(getPlayer1Score() + 1);
		}
	}
	
	public void addPlayer2Score() {
		if (getPlayer2Score() < 3) {
			setPlayer2Score(getPlayer2Score() + 1);
		}
	}
	
	public int getPlayer1Score() {
		return p1;
	}
	
	public int getPlayer2Score() {
		return p2;
	}
	
	public String checkWinner(int p1, int p2) {
		String winner = "";
		
		if (p1 >= 4 && p1 - p2 >= 2) {
			winner = "Player1";
		} else if (p2 >= 4 && p2 - p1 >= 2) {
			winner = "Player2";
		}
		
		return winner;
	};
	
	
	public String checkSpecial(int p1, int p2) {
		// Check if there's a advantage or a deuce
		String advangate = "";
	
		if (p1 >= 3 && p2 >= 3) {
			if (p1 > p2) {
				advangate = "Advantage Player1";
			} else if (p2 > p1) {
				advangate = "Advantage Player2";
			} else {
				advangate = "Deuce";
			}
		}
		
		return advangate;
	}
	
	public void printScore(int p1, int p2) {
		
		int p1score = 0;
		int p2score = 0;
		
		switch (p1) {
		case 1:
			p1score = 15;
			break;
		case 2:
			p1score = 30;
			break;
		case 3:
			p1score = 40;
			break;
		case 4:
			p1score = 45;
		}
		
		switch (p2) {
		case 1:
			p2score = 15;
			break;
		case 2:
			p2score = 30;
			break;
		case 3:
			p2score = 40;
			break;
		case 4:
			p2score = 45;
		}
		
		System.out.println(p1score + " - " + p2score);
	}
	
	public String getScore() {
		String winner = "";
		String advantage = "";
		
		int p1 = getPlayer1Score();
		int p2 = getPlayer2Score();
		
		printScore(p1, p2);
		winner = checkWinner(p1, p2);
		advantage = checkSpecial(p1, p2);

		if (winner != "") {
			System.out.println("Game " + winner);
		} else if (advantage != "") {
			System.out.println(advantage);
		}
		
		return winner;
	}
}
